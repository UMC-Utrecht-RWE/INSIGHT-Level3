###################################################
#Study Parameters
#################################################
#females age
min_age_preg<-12
max_age_preg<-55
#Set parameters basic parameters
start_study_date <- "19950101"
end_study_date <- "20211231"
#start_study_date <- "20140101"
#end_study_date <- "20181231"
lookback_period <- 365
Age_max <- 56
Age_min <- 0