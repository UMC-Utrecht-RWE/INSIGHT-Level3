#Author: Vjola Hoxhaj Drs.
#email: v.hoxhaj@umcutrecht.nl
#Organisation: UMC Utrecht, Utrecht, The Netherlands
#Date: 09/07/2022

#####Source needed parameters#####
source(paste0(pre_dir, "DAP_info.R")) 
source(paste0(pre_dir,"info.R"))
source(paste0(pre_dir, "date_parameters.R"))
source(paste0(pre_dir, "time_lag_recurrent_events_parameters.R"))

#####Load list of events for recurrent events analysis/first event analysis#####
#Load code list
if(!is.null(study_name_codelist)){
  codelist_directory<-list.files(pre_dir,paste0("^", study_name_codelist))
  codelist<-fread(paste0(pre_dir,codelist_directory), colClasses = "character")
  codelist[,event_definition:=gsub("-","_",event_definition)]
} else {
  codelist<-fread(paste0(pre_dir,"Data_characterisation_EVENTS_codelist.csv"), colClasses = "character")
}
codelist<-codelist[!duplicated(event_definition),event_definition]

#####Create output folders#####
if (subpopulations_present=="No"){
  
  if ("POI" %in% list.files(output_dir)){
    unlink(paste0(output_dir,"POI"), recursive = T)#delete folder
    dir.create(paste(output_dir, "POI", sep=""))
    poi_dir<-paste(output_dir, "POI/", sep="")
    
    #EVENTS_PREGNANCY
    dir.create(paste(poi_dir, "EVENTS_PREGNANCY", sep=""))
    ev_preg_dir<-paste(poi_dir, "EVENTS_PREGNANCY/", sep="")
    dir.create(paste(ev_preg_dir,"Masked", sep=""))
    
    #MEDICINES_PREGNANCY
    dir.create(paste(poi_dir, "MEDICINES_PREGNANCY", sep=""))
    med_preg_dir<-paste(poi_dir, "MEDICINES_PREGNANCY/", sep="")
    dir.create(paste(med_preg_dir,"Masked", sep=""))
    
    #VACCINES_PREGNANCY
    dir.create(paste(poi_dir, "VACCINES_PREGNANCY", sep=""))
    vacc_preg_dir<-paste(poi_dir, "VACCINES_PREGNANCY/", sep="")
    dir.create(paste(vacc_preg_dir,"Masked", sep=""))
    
    #EVENTS_MEDICINES_PREGNANCY
    dir.create(paste(poi_dir, "EVENTS_MEDICINES_PREGNANCY", sep=""))
    ev_med_preg_dir<-paste(poi_dir, "EVENTS_MEDICINES_PREGNANCY/", sep="")
    dir.create(paste(ev_med_preg_dir,"Masked", sep=""))
    
    #EVENTS_VACCINES_PREGNANCY
    dir.create(paste(poi_dir, "EVENTS_VACCINES_PREGNANCY", sep=""))
    ev_vacc_preg_dir<-paste(poi_dir, "EVENTS_VACCINES_PREGNANCY/", sep="")
    dir.create(paste(ev_vacc_preg_dir,"Masked", sep=""))
    
    #EVENTS_MEDICINES
    dir.create(paste(poi_dir, "EVENTS_MEDICINES", sep=""))
    ev_med_dir<-paste(poi_dir, "EVENTS_MEDICINES/", sep="")
    dir.create(paste(ev_med_dir,"Masked", sep=""))
    
    #EVENTS_VACCINES
    dir.create(paste(poi_dir, "EVENTS_VACCINES", sep=""))
    ev_vacc_dir<-paste(poi_dir, "EVENTS_VACCINES/", sep="")
    dir.create(paste(ev_vacc_dir,"Masked", sep=""))
    
    
  } else {
    #Create the  folder in the output dir
    dir.create(paste(output_dir, "POI", sep=""))
    poi_dir<-paste(output_dir, "POI/", sep="")
    
    #EVENTS_PREGNANCY
    dir.create(paste(poi_dir, "EVENTS_PREGNANCY", sep=""))
    ev_preg_dir<-paste(poi_dir, "EVENTS_PREGNANCY/", sep="")
    dir.create(paste(ev_preg_dir,"Masked", sep=""))
    
    #MEDICINES_PREGNANCY
    dir.create(paste(poi_dir, "MEDICINES_PREGNANCY", sep=""))
    med_preg_dir<-paste(poi_dir, "MEDICINES_PREGNANCY/", sep="")
    dir.create(paste(med_preg_dir,"Masked", sep=""))
    
    #VACCINES_PREGNANCY
    dir.create(paste(poi_dir, "VACCINES_PREGNANCY", sep=""))
    vacc_preg_dir<-paste(poi_dir, "VACCINES_PREGNANCY/", sep="")
    dir.create(paste(vacc_preg_dir,"Masked", sep=""))
    
    #EVENTS_MEDICINES_PREGNANCY
    dir.create(paste(poi_dir, "EVENTS_MEDICINES_PREGNANCY", sep=""))
    ev_med_preg_dir<-paste(poi_dir, "EVENTS_MEDICINES_PREGNANCY/", sep="")
    dir.create(paste(ev_med_preg_dir,"Masked", sep=""))
    
    #EVENTS_VACCINES_PREGNANCY
    dir.create(paste(poi_dir, "EVENTS_VACCINES_PREGNANCY", sep=""))
    ev_vacc_preg_dir<-paste(poi_dir, "EVENTS_VACCINES_PREGNANCY/", sep="")
    dir.create(paste(ev_vacc_preg_dir,"Masked", sep=""))
    
    #EVENTS_MEDICINES
    dir.create(paste(poi_dir, "EVENTS_MEDICINES", sep=""))
    ev_med_dir<-paste(poi_dir, "EVENTS_MEDICINES/", sep="")
    dir.create(paste(ev_med_dir,"Masked", sep=""))
    
    #EVENTS_VACCINES
    dir.create(paste(poi_dir, "EVENTS_VACCINES", sep=""))
    ev_vacc_dir<-paste(poi_dir, "EVENTS_VACCINES/", sep="")
    dir.create(paste(ev_vacc_dir,"Masked", sep=""))
    
  }
  
  #########################################################################
  #output ev_preg_pop_study_population in g_intermediate/populations/ev_preg_pop
  if ("EVENTS_PREGNANCY" %in% list.files(populations_dir)){
    unlink(paste0(populations_dir,"EVENTS_PREGNANCY"), recursive = T)#delete folder
    dir.create(paste(populations_dir, "EVENTS_PREGNANCY", sep=""))
    ev_preg_pop<-paste(populations_dir, "EVENTS_PREGNANCY/", sep="")
  } else {
    #Create the EVENTS_PREGNANCY folder in the output dir
    dir.create(paste(populations_dir, "EVENTS_PREGNANCY", sep=""))
    ev_preg_pop<-paste(populations_dir, "EVENTS_PREGNANCY/", sep="")
  }
  
  #output med_preg_dir_study_population in g_intermediate/populations/med_preg_dir
  if ("MEDICINES_PREGNANCY" %in% list.files(populations_dir)){
    unlink(paste0(populations_dir,"MEDICINES_PREGNANCY"), recursive = T)#delete folder
    dir.create(paste(populations_dir, "MEDICINES_PREGNANCY", sep=""))
    med_preg_pop<-paste(populations_dir, "MEDICINES_PREGNANCY/", sep="")
  } else {
    #Create the EVENTS_PREGNANCY folder in the output dir
    dir.create(paste(populations_dir, "MEDICINES_PREGNANCY", sep=""))
    med_preg_pop<-paste(populations_dir, "MEDICINES_PREGNANCY/", sep="")
  }
  
  #output vacc_preg_pop_study_population in g_intermediate/populations/vacc_preg_pop
  if ("VACCINES_PREGNANCY" %in% list.files(populations_dir)){
    unlink(paste0(populations_dir,"VACCINES_PREGNANCY"), recursive = T)#delete folder
    dir.create(paste(populations_dir, "VACCINES_PREGNANCY", sep=""))
    vacc_preg_pop<-paste(populations_dir, "VACCINES_PREGNANCY/", sep="")
  } else {
    #Create the EVENTS_PREGNANCY folder in the output dir
    dir.create(paste(populations_dir, "VACCINES_PREGNANCY", sep=""))
    vacc_preg_pop<-paste(populations_dir, "VACCINES_PREGNANCY/", sep="")
  }
  
  if ("EVENTS_MEDICINES_PREGNANCY" %in% list.files(populations_dir)){
    unlink(paste0(populations_dir,"EVENTS_MEDICINES_PREGNANCY"), recursive = T)#delete folder
    dir.create(paste(populations_dir, "EVENTS_MEDICINES_PREGNANCY", sep=""))
    ev_med_preg_pop<-paste(populations_dir, "EVENTS_MEDICINES_PREGNANCY/", sep="")
  } else {
    #Create the  folder in the output dir
    dir.create(paste(populations_dir, "EVENTS_MEDICINES_PREGNANCY", sep=""))
    ev_med_preg_pop<-paste(populations_dir, "EVENTS_MEDICINES_PREGNANCY/", sep="")
  }
  
  if ("EVENTS_VACCINES_PREGNANCY" %in% list.files(populations_dir)){
    unlink(paste0(populations_dir,"EVENTS_VACCINES_PREGNANCY"), recursive = T)#delete folder
    dir.create(paste(populations_dir, "EVENTS_VACCINES_PREGNANCY", sep=""))
    ev_vacc_preg_pop<-paste(populations_dir, "EVENTS_VACCINES_PREGNANCY/", sep="")
  } else {
    #Create the  folder in the output dir
    dir.create(paste(populations_dir, "EVENTS_VACCINES_PREGNANCY", sep=""))
    ev_vacc_preg_pop<-paste(populations_dir, "EVENTS_VACCINES_PREGNANCY/", sep="")
  }
  
  if ("EVENTS_MEDICINES" %in% list.files(populations_dir)){
    unlink(paste0(populations_dir,"EVENTS_MEDICINES"), recursive = T)#delete folder
    dir.create(paste(populations_dir, "EVENTS_MEDICINES", sep=""))
    ev_med_pop<-paste(populations_dir, "EVENTS_MEDICINES/", sep="")
  } else {
    #Create the  folder in the output dir
    dir.create(paste(populations_dir, "EVENTS_MEDICINES", sep=""))
    ev_med_pop<-paste(populations_dir, "EVENTS_MEDICINES/", sep="")
  }
  
  if ("EVENTS_VACCINES" %in% list.files(populations_dir)){
    unlink(paste0(populations_dir,"EVENTS_VACCINES"), recursive = T)#delete folder
    dir.create(paste(populations_dir, "EVENTS_VACCINES", sep=""))
    ev_vacc_pop<-paste(populations_dir, "EVENTS_VACCINES/", sep="")
  } else {
    #Create the  folder in the output dir
    dir.create(paste(populations_dir, "EVENTS_VACCINES", sep=""))
    ev_vacc_pop<-paste(populations_dir, "EVENTS_VACCINES/", sep="")
  }
  
  #POI_tmp/POI folder where all intermediary files are saved
  if ("POI" %in% list.files(tmp)){
    unlink(paste0(tmp,"POI"), recursive = T)#delete folder
    dir.create(paste(tmp, "POI", sep=""))
    poi_tmp<-paste(tmp, "POI/", sep="")
  }else{
    #Create the POI folder in the output dir
    dir.create(paste(tmp, "POI", sep=""))
    poi_tmp<-paste(tmp, "POI/", sep="")
  }
} else {
  
  if ("POI" %in% list.files(output_dir)){
    unlink(paste0(output_dir,"POI"), recursive = T)#delete folder
    dir.create(paste(output_dir, "POI", sep=""))
    poi_dir<-paste(output_dir, "POI/", sep="")
    
    #EVENTS_PREGNANCY
    dir.create(paste(poi_dir, "EVENTS_PREGNANCY", sep=""))
    ev_preg_dir<-paste(poi_dir, "EVENTS_PREGNANCY/", sep="")
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(ev_preg_dir, subpopulations_names[i]))
    }
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(ev_preg_dir, subpopulations_names[i],"/Masked"))
    }
    
    #MEDICINES_PREGNANCY
    dir.create(paste(poi_dir, "MEDICINES_PREGNANCY", sep=""))
    med_preg_dir<-paste(poi_dir, "MEDICINES_PREGNANCY/", sep="")
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(med_preg_dir, subpopulations_names[i]))
    }
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(med_preg_dir, subpopulations_names[i],"/Masked"))
    }
    
    
    #VACCINES_PREGNANCY
    dir.create(paste(poi_dir, "VACCINES_PREGNANCY", sep=""))
    vacc_preg_dir<-paste(poi_dir, "VACCINES_PREGNANCY/", sep="")
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(vacc_preg_dir, subpopulations_names[i]))
    }
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(vacc_preg_dir, subpopulations_names[i],"/Masked"))
    }
    
    #EVENTS_MEDICINES_PREGNANCY
    dir.create(paste(poi_dir, "EVENTS_MEDICINES_PREGNANCY", sep=""))
    ev_med_preg_dir<-paste(poi_dir, "EVENTS_MEDICINES_PREGNANCY/", sep="")
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(ev_med_preg_dir, subpopulations_names[i]))
    }
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(ev_med_preg_dir, subpopulations_names[i],"/Masked"))
    }
    
    
    #EVENTS_VACCINES_PREGNANCY
    dir.create(paste(poi_dir, "EVENTS_VACCINES_PREGNANCY", sep=""))
    ev_vacc_preg_dir<-paste(poi_dir, "EVENTS_VACCINES_PREGNANCY/", sep="")
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(ev_vacc_preg_dir, subpopulations_names[i]))
    }
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(ev_vacc_preg_dir, subpopulations_names[i],"/Masked"))
    }
    
    
    #EVENTS_MEDICINES
    dir.create(paste(poi_dir, "EVENTS_MEDICINES", sep=""))
    ev_med_dir<-paste(poi_dir, "EVENTS_MEDICINES/", sep="")
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(ev_med_dir, subpopulations_names[i]))
    }
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(ev_med_dir, subpopulations_names[i],"/Masked"))
    }
    
    #EVENTS_VACCINES
    dir.create(paste(poi_dir, "EVENTS_VACCINES", sep=""))
    ev_vacc_dir<-paste(poi_dir, "EVENTS_VACCINES/", sep="")
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(ev_vacc_dir, subpopulations_names[i]))
    }
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(ev_vacc_dir, subpopulations_names[i],"/Masked"))
    }
    
    
  } else {
    #Create the  folder in the output dir
    dir.create(paste(output_dir, "POI", sep=""))
    poi_dir<-paste(output_dir, "POI/", sep="")
    
    #EVENTS_PREGNANCY
    dir.create(paste(poi_dir, "EVENTS_PREGNANCY", sep=""))
    ev_preg_dir<-paste(poi_dir, "EVENTS_PREGNANCY/", sep="")
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(ev_preg_dir, subpopulations_names[i]))
    }
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(ev_preg_dir, subpopulations_names[i],"/Masked"))
    }
    
    #MEDICINES_PREGNANCY
    dir.create(paste(poi_dir, "MEDICINES_PREGNANCY", sep=""))
    med_preg_dir<-paste(poi_dir, "MEDICINES_PREGNANCY/", sep="")
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(med_preg_dir, subpopulations_names[i]))
    }
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(med_preg_dir, subpopulations_names[i],"/Masked"))
    }
    
    
    #VACCINES_PREGNANCY
    dir.create(paste(poi_dir, "VACCINES_PREGNANCY", sep=""))
    vacc_preg_dir<-paste(poi_dir, "VACCINES_PREGNANCY/", sep="")
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(vacc_preg_dir, subpopulations_names[i]))
    }
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(vacc_preg_dir, subpopulations_names[i],"/Masked"))
    }
    
    #EVENTS_MEDICINES_PREGNANCY
    dir.create(paste(poi_dir, "EVENTS_MEDICINES_PREGNANCY", sep=""))
    ev_med_preg_dir<-paste(poi_dir, "EVENTS_MEDICINES_PREGNANCY/", sep="")
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(ev_med_preg_dir, subpopulations_names[i]))
    }
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(ev_med_preg_dir, subpopulations_names[i],"/Masked"))
    }
    
    
    #EVENTS_VACCINES_PREGNANCY
    dir.create(paste(poi_dir, "EVENTS_VACCINES_PREGNANCY", sep=""))
    ev_vacc_preg_dir<-paste(poi_dir, "EVENTS_VACCINES_PREGNANCY/", sep="")
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(ev_vacc_preg_dir, subpopulations_names[i]))
    }
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(ev_vacc_preg_dir, subpopulations_names[i],"/Masked"))
    }
    
    
    #EVENTS_MEDICINES
    dir.create(paste(poi_dir, "EVENTS_MEDICINES", sep=""))
    ev_med_dir<-paste(poi_dir, "EVENTS_MEDICINES/", sep="")
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(ev_med_dir, subpopulations_names[i]))
    }
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(ev_med_dir, subpopulations_names[i],"/Masked"))
    }
    
    #EVENTS_VACCINES
    dir.create(paste(poi_dir, "EVENTS_VACCINES", sep=""))
    ev_vacc_dir<-paste(poi_dir, "EVENTS_VACCINES/", sep="")
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(ev_vacc_dir, subpopulations_names[i]))
    }
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(ev_vacc_dir, subpopulations_names[i],"/Masked"))
    }
    
  }
  
  
  ###################################################################
  if ("EVENTS_PREGNANCY" %in% list.files(populations_dir)){
    unlink(paste0(populations_dir,"EVENTS_PREGNANCY"), recursive = T)#delete folder
    dir.create(paste(populations_dir, "EVENTS_PREGNANCY", sep=""))
    ev_preg_pop<-paste(populations_dir, "EVENTS_PREGNANCY/",sep="")
    do.call(file.remove, list(list.files(ev_preg_pop, full.names = T)))
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(ev_preg_pop, subpopulations_names[i]))
    }
  } else {
    #Create the EVENTS_PREGNANCY folder in the output dir
    dir.create(paste(populations_dir, "EVENTS_PREGNANCY", sep=""))
    ev_preg_pop<-paste(populations_dir, "EVENTS_PREGNANCY/", sep="")
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(ev_preg_pop, subpopulations_names[i]))
    }
  }
  
  if ("MEDICINES_PREGNANCY" %in% list.files(populations_dir)){
    unlink(paste0(populations_dir,"MEDICINES_PREGNANCY"), recursive = T)#delete folder
    dir.create(paste(populations_dir, "MEDICINES_PREGNANCY", sep=""))
    med_preg_pop<-paste(populations_dir, "MEDICINES_PREGNANCY/",sep="")
    do.call(file.remove, list(list.files(med_preg_pop, full.names = T)))
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(med_preg_pop, subpopulations_names[i]))
    }
  } else {
    #Create the MEDICINES_PREGNANCY folder in the output dir
    dir.create(paste(populations_dir, "MEDICINES_PREGNANCY", sep=""))
    med_preg_pop<-paste(populations_dir, "MEDICINES_PREGNANCY/", sep="")
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(med_preg_pop, subpopulations_names[i]))
    }
  }
  
  if ("VACCINES_PREGNANCY" %in% list.files(populations_dir)){
    unlink(paste0(populations_dir,"VACCINES_PREGNANCY"), recursive = T)#delete folder
    dir.create(paste(populations_dir, "VACCINES_PREGNANCY", sep=""))
    vacc_preg_pop<-paste(populations_dir, "VACCINES_PREGNANCY/",sep="")
    do.call(file.remove, list(list.files(vacc_preg_pop, full.names = T)))
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(vacc_preg_pop, subpopulations_names[i]))
    }
  } else {
    #Create the VACCINES_PREGNANCY folder in the output dir
    dir.create(paste(populations_dir, "VACCINES_PREGNANCY", sep=""))
    vacc_preg_pop<-paste(populations_dir, "VACCINES_PREGNANCY/", sep="")
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(vacc_preg_pop, subpopulations_names[i]))
    }
  }
  
  if ("EVENTS_MEDICINES_PREGNANCY" %in% list.files(populations_dir)){
    unlink(paste0(populations_dir,"EVENTS_MEDICINES_PREGNANCY"), recursive = T)#delete folder
    dir.create(paste(populations_dir, "EVENTS_MEDICINES_PREGNANCY", sep=""))
    ev_med_preg_pop<-paste(populations_dir, "EVENTS_MEDICINES_PREGNANCY/",sep="")
    do.call(file.remove, list(list.files(ev_med_preg_pop, full.names = T)))
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(ev_med_preg_pop, subpopulations_names[i]))
    }
  } else {
    #Create the EVENTS_MEDICINES_PREGNANCY folder in the output dir
    dir.create(paste(populations_dir, "EVENTS_MEDICINES_PREGNANCY", sep=""))
    ev_med_preg_pop<-paste(populations_dir, "EVENTS_MEDICINES_PREGNANCY/", sep="")
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(ev_med_preg_pop, subpopulations_names[i]))
    }
  }
  
  if ("EVENTS_VACCINES_PREGNANCY" %in% list.files(populations_dir)){
    unlink(paste0(populations_dir,"EVENTS_VACCINES_PREGNANCY"), recursive = T)#delete folder
    dir.create(paste(populations_dir, "EVENTS_VACCINES_PREGNANCY", sep=""))
    ev_vacc_preg_pop<-paste(populations_dir, "EVENTS_VACCINES_PREGNANCY/",sep="")
    do.call(file.remove, list(list.files(ev_vacc_preg_pop, full.names = T)))
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(ev_vacc_preg_pop, subpopulations_names[i]))
    }
  } else {
    #Create the EVENTS_VACCINES_PREGNANCY folder in the output dir
    dir.create(paste(populations_dir, "EVENTS_VACCINES_PREGNANCY", sep=""))
    ev_vacc_preg_pop<-paste(populations_dir, "EVENTS_VACCINES_PREGNANCY/", sep="")
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(ev_vacc_preg_pop, subpopulations_names[i]))
    }
  }
  
  if ("EVENTS_MEDICINES" %in% list.files(populations_dir)){
    unlink(paste0(populations_dir,"EVENTS_MEDICINES"), recursive = T)#delete folder
    dir.create(paste(populations_dir, "EVENTS_MEDICINES", sep=""))
    ev_med_pop<-paste(populations_dir, "EVENTS_MEDICINES/",sep="")
    do.call(file.remove, list(list.files(ev_med_pop, full.names = T)))
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(ev_med_pop, subpopulations_names[i]))
    }
  } else {
    #Create the EVENTS_MEDICINES folder in the output dir
    dir.create(paste(populations_dir, "EVENTS_MEDICINES", sep=""))
    ev_med_pop<-paste(populations_dir, "EVENTS_MEDICINES/", sep="")
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(ev_med_pop, subpopulations_names[i]))
    }
  }
  
  if ("EVENTS_VACCINES" %in% list.files(populations_dir)){
    unlink(paste0(populations_dir,"EVENTS_VACCINES"), recursive = T)#delete folder
    dir.create(paste(populations_dir, "EVENTS_VACCINES", sep=""))
    ev_vacc_pop<-paste(populations_dir, "EVENTS_VACCINES/",sep="")
    do.call(file.remove, list(list.files(ev_vacc_pop, full.names = T)))
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(ev_vacc_pop, subpopulations_names[i]))
    }
  } else {
    #Create the EVENTS_VACCINES folder in the output dir
    dir.create(paste(populations_dir, "EVENTS_VACCINES", sep=""))
    ev_vacc_pop<-paste(populations_dir, "EVENTS_VACCINES/", sep="")
    for (i in 1:length(subpopulations_names)){
      dir.create(paste0(ev_vacc_pop, subpopulations_names[i]))
    }
  }
  
  
  #POI_tmp/POI folder where all intermediary files are saved
  if ("POI" %in% list.files(tmp)){
    unlink(paste0(tmp,"POI"), recursive = T)#delete folder
    dir.create(paste(tmp, "POI", sep=""))
    poi_tmp<-paste(tmp, "POI/", sep="")
  }else{
    #Create the POI folder in the output dir
    dir.create(paste(tmp, "POI", sep=""))
    poi_tmp<-paste(tmp, "POI/", sep="")
  }
}


####Main script####
if(sum(diagnoses,pregnancies)>0){
  if (subpopulations_present=="Yes"){
    #Load diagnoses files
    for (s in 1: length(subpopulations_names)){
      diagnoses_files<-list.files(paste0(diag_pop,subpopulations_names[s],"/"))
      files<-list()
      for (i in 1: length(diagnoses_files)){
        files<-append(files,unique(list(unlist(str_split(diagnoses_files[i],"_"))[2])))
      }
      files<-do.call(c,files)
      #remove duplicates 
      files<-files[!duplicated(files)]
      
      #Check for recurrent events analysis
      if(recurrent_event_analysis %in% c("Yes","yes","YES")){
        rec_events_list<-codelist[codelist %in% recurrent_events_list]
        rec_events_list<-files[files %in% rec_events_list]
        #Load list of events
      }else{
        rec_events_list<-NULL 
      } 
      
      #First events analysis
      first_events_list<-files[files %in% codelist]
      first_events_list<-first_events_list[!first_events_list %in% recurrent_events_list]
      
 
      source(paste0(pre_dir,"Step_11_01_PREGNANCY_L3_pre_script_EVENTS.R"))
      source(paste0(pre_dir,"Step_11_02_PREGNANCY_L3_pre_script_MO.R"))
      source(paste0(pre_dir,"Step_11_03_PREGNANCY_L3_pre_script_SO.R"))
      source(paste0(pre_dir,"Step_11_04_PREGNANCY_L3_pre_script_SI.R"))
      source(paste0(pre_dir,"Step_11_05_PREGNANCY_L3_pre_script_Results.R"))
      
      
      do.call(file.remove, list(list.files(preg_ev_tmp, full.names = T)))
      do.call(file.remove, list(list.files(preg_m_tmp, full.names = T)))
      do.call(file.remove, list(list.files(preg_s_tmp, full.names = T)))
      do.call(file.remove, list(list.files(preg_si_tmp, full.names = T)))
      do.call(file.remove, list(list.files(preg_tmp, full.names = T)))
      
    }
  } else {
    #Load diagnoses files
    diagnoses_files<-list.files(diag_pop)
    files<-list()
    for (i in 1: length(diagnoses_files)){
      files<-append(files,unique(list(unlist(str_split(diagnoses_files[i],"_"))[2])))
    }
    files<-do.call(c,files)
    #remove duplicates 
    files<-files[!duplicated(files)]
    
    #Check for recurrent events analysis
    if(recurrent_event_analysis %in% c("Yes","yes","YES")){
      rec_events_list<-codelist[codelist %in% recurrent_events_list]
      rec_events_list<-files[files %in% rec_events_list]
      #Load list of events
    }else{
      rec_events_list<-NULL 
    } 
    
    #First events analysis
    first_events_list<-files[files %in% codelist]
    first_events_list<-first_events_list[!first_events_list %in% recurrent_events_list]
    
    
    source(paste0(pre_dir,"Step_11_01_PREGNANCY_L3_pre_script_EVENTS.R"))
    source(paste0(pre_dir,"Step_11_02_PREGNANCY_L3_pre_script_MO.R"))
    source(paste0(pre_dir,"Step_11_03_PREGNANCY_L3_pre_script_SO.R"))
    source(paste0(pre_dir,"Step_11_04_PREGNANCY_L3_pre_script_SI.R"))
    source(paste0(pre_dir,"Step_11_05_PREGNANCY_L3_pre_script_Results.R"))
    
    do.call(file.remove, list(list.files(preg_ev_tmp, full.names = T)))
    do.call(file.remove, list(list.files(preg_m_tmp, full.names = T)))
    do.call(file.remove, list(list.files(preg_s_tmp, full.names = T)))
    do.call(file.remove, list(list.files(preg_si_tmp, full.names = T)))
    do.call(file.remove, list(list.files(preg_tmp, full.names = T)))
  }
}

#Delete folders poi from tmp
unlink(paste0(tmp,"POI"), recursive = T)

keep_environment<-c("StudyName", "data_access_provider_name", "data_source_name", "subpopulations_names", "subpopulations_present", "subpopulations","SUBP",
                    "Age_max","Age_min", "min_age_preg","max_age_preg",
                    "start_study_date","end_study_date", "lookback_period", "intv","recommended_end_date", "date_creation","start_study_date2","end_study_date2",
                    "METADATA_subp", "actual_tables", "tmp", "s", "meanings_birth_registry","CountPersonTime2",
                    "diagnoses","pregnancies","diagnoses_pregnancy_med_vacc","diagnoses_pregnancy_med","diagnoses_pregnancy_vacc","pregnancy_only_med_vacc","pregnancy_only_med","pregnancy_only_vacc",
                    "dir_base", "populations_dir", "output_dir", "pre_dir", "study_population_dir", "g_intermediate", "path_dir","projectFolder","path","path_output",
                    "med_dir","medicines_tmp","medicines_pop", "Rmd_MEDICINES",
                    "vacc_dir", "vaccines_tmp", "vaccines_pop","Rmd_VACCINES",
                    "diag_dir", "events_tmp","mo_tmp","so_tmp","diag_tmp", "diag_pop","Rmd_DIAGNOSES", "conditions","diagnoses","duplicated_event_dates","remove_subj",
                    "preg_dir","preg_ev_tmp","preg_m_tmp","preg_s_tmp","preg_si_tmp","preg_tmp", "preg_pop","Rmd_PREGNANCY","pregnancies",
                    "poi_dir","ev_preg_dir","med_preg_dir","vacc_preg_dir","ev_med_preg_dir","ev_vacc_preg_dir","ev_med_dir","ev_vacc_dir","ev_preg_pop","med_preg_pop","vacc_preg_pop","ev_med_preg_pop","ev_vacc_preg_pop","ev_med_pop","ev_vacc_pop","poi_tmp","Rmd_POI")

list_rm<-ls()[ls() %!in% keep_environment]
rm(list = list_rm)
rm(list_rm)
`%!in%` = Negate(`%in%`)


